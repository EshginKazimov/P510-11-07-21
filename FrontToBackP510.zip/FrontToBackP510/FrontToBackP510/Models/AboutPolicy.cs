﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP510.Models
{
    public class AboutPolicy
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}

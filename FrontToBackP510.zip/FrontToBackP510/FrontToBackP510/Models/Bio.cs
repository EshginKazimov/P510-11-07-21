﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontToBackP510.Models
{
    public class Bio
    {
        public int Id { get; set; }

        public string Logo { get; set; }

        public string FacebookUrl { get; set; }

        public string LinkedInUrl { get; set; }
    }
}

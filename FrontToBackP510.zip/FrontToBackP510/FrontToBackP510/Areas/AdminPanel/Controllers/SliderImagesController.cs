﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using FrontToBackP510.Areas.AdminPanel.Data;
using FrontToBackP510.DataAccessLayer;
using FrontToBackP510.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;

namespace FrontToBackP510.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class SliderImagesController : Controller
    {
        private readonly AppDbContext _dbContext;

        public SliderImagesController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var sliderImages = await _dbContext.SliderImages.ToListAsync();

            return View(sliderImages);
        }

        public IActionResult Create()
        {
            if (_dbContext.SliderImages.Count() >= 5)
            {
                return RedirectToAction("Index");
            }

            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SliderImage sliderImage)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            var uploadedImageCount = 5 - _dbContext.SliderImages.Count();
            if (uploadedImageCount < sliderImage.Photos.Length)
            {
                ModelState.AddModelError("Photos", $"Max {uploadedImageCount} shekil icaze verilir.");
                return View();
            }

            foreach (var photo in sliderImage.Photos)
            {
                if (!photo.IsImage())
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} shekil deil.");
                    return View();
                }

                var allowedSizeInMb = 1;
                if (!photo.IsSizeAllowed(allowedSizeInMb))
                {
                    ModelState.AddModelError("Photos", $"{photo.FileName} shekli {allowedSizeInMb}Mb-dan choxdur.");
                    return View();
                }

                var imageName = await FileManager.GenerateFileAsync(photo, Constants.ImageFolderPath);

                var addedSlider = new SliderImage
                {
                    Image = imageName
                };

                await _dbContext.SliderImages.AddAsync(addedSlider);
                await _dbContext.SaveChangesAsync();
            }

            return RedirectToAction("Index");
        }

        #region Single file upload

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Create(SliderImage sliderImage)
        //{
        //    if (_dbContext.SliderImages.Count() >= 5)
        //    {
        //        return BadRequest();
        //    }

        //    if (!ModelState.IsValid)
        //    {
        //        return View();
        //    }

        //    if (!sliderImage.Photo.IsImage())
        //    {
        //        ModelState.AddModelError("Photo", "Yuklediyiniz shekil deil.");
        //        return View();
        //    }

        //    var allowedSizeInMb = 1;
        //    if (!sliderImage.Photo.IsSizeAllowed(allowedSizeInMb))
        //    {
        //        ModelState.AddModelError("Photo", $"Yuklediyiniz shekil {allowedSizeInMb}Mb-dan choxdur.");
        //        return View();
        //    }

        //    var imageName = await FileManager.GenerateFileAsync(sliderImage.Photo, Constants.ImageFolderPath);

        //    sliderImage.Image = imageName;
        //    await _dbContext.SliderImages.AddAsync(sliderImage);
        //    await _dbContext.SaveChangesAsync();

        //    return RedirectToAction("Index");
        //}

        #endregion

        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            return View(sliderImage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public async Task<IActionResult> DeleteImage(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            FileManager.DeleteFile(Constants.ImageFolderPath, sliderImage.Image);

            _dbContext.SliderImages.Remove(sliderImage);
            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Update(int? id)
        {
            if (id == null)
                return NotFound();

            var sliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (sliderImage == null)
                return NotFound();

            return View(sliderImage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Update(int? id, SliderImage sliderImage)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }

            if (id == null)
                return NotFound();

            if (id != sliderImage.Id)
                return NotFound();

            if (!sliderImage.Photo.IsImage())
            {
                ModelState.AddModelError("Photo", "Yuklediyiniz shekil deil.");
                return View(sliderImage);
            }

            var dbSliderImage = await _dbContext.SliderImages.FindAsync(id);
            if (dbSliderImage == null)
                return NotFound();

            var allowedSizeInMb = 1;
            if (!sliderImage.Photo.IsSizeAllowed(allowedSizeInMb))
            {
                sliderImage.Image = dbSliderImage.Image;
                ModelState.AddModelError("Photo", $"Yuklediyiniz shekil {allowedSizeInMb}Mb-dan choxdur.");
                return View(sliderImage);
            }

            FileManager.DeleteFile(Constants.ImageFolderPath, dbSliderImage.Image);

            var imageName = await FileManager.GenerateFileAsync(sliderImage.Photo, Constants.ImageFolderPath);

            dbSliderImage.Image = imageName;
            await _dbContext.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
